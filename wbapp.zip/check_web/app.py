import os
from flask import Flask, request, send_file, jsonify, render_template
from PIL import Image

app = Flask(__name__)
UPLOAD_FOLDER = 'uploads'
RESULT_FOLDER = 'results'

# Ensure folders exist
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(RESULT_FOLDER, exist_ok=True)

@app.route('/')
def home():
    # Serve the HTML page
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_files():
    username = request.form['username']
    images = request.files.getlist('images')

    if not username or len(images) != 5:
        return jsonify({"error": "Invalid input. Please provide a name and exactly 5 images."}), 400

    # Create a folder for the user
    user_folder = os.path.join(UPLOAD_FOLDER, username)
    os.makedirs(user_folder, exist_ok=True)

    # Save uploaded images to the user's folder
    saved_images = []
    for idx, image in enumerate(images):
        file_path = os.path.join(user_folder, f"image_{idx + 1}.png")
        image.save(file_path)
        saved_images.append(file_path)

    # Convert images to black and white
    result_images = []
    for image_path in saved_images:
        img = Image.open(image_path).convert("L")  # Convert to grayscale
        result_path = os.path.join(RESULT_FOLDER, f"{username}_bw_{os.path.basename(image_path)}")
        img.save(result_path)
        result_images.append(result_path)

    # Return one processed image as the result
    return send_file(result_images[0], mimetype='image/png')

if __name__ == '__main__':
    app.run(debug=True)
